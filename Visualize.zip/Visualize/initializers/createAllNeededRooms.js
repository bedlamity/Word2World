'use strict';

module.exports = {
  loadPriority:  1000,
  startPriority: 1000,
  stopPriority:  1000,
  initialize: function(api, next){
    api.createAllNeededRooms = {};

    next();
  },
  start: function(api, next){
	//Create our two rooms.
	
	//Room 1 is the chat room, where players can type things in
	//and exchange messages that they can read. So for example, telling
	//the score, or calling timeout, or complaining about out of bounds.
	api.chatRoom.add("playerChatRoom", null);
	
	//Room 2 is the movement room. So players don't actually type things in here.
	//Instead when they move their character around, using either the mouse/ touchpad/
	//arrow keys, or when they kick the ball, then location messages are automatically sent
	//through this channel. After the movements are sanitized by the server (no cheating),
	//they are broadcast to all of the clients.
	api.chatRoom.add("movementUpdatesRoom", null);
	
    next();
  },
  stop: function(api, next){
    next();
  }
};

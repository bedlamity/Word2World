'use strict';

exports.action = {
  name:                   'testRedis',
  description:            'My Action',
  blockedConnectionTypes: [],
  outputExample:          {},
  matchExtensionMimeType: false,
  version:                1.0,
  toDocument:             true,
  middleware:             [],

  inputs: {},

  run: function(api, data, next) {
    let error = null;
	
    var redis = api.redis.clients.client;
	var key = "user1";
	redis.get(key, function(error, result){
		if (error) console.log('Error: '+ error);
		else console.log('Name: ' + result);
	});
	//var data = "andrew"
/*	redis.hgetall(key, function(error, data){
		var comments = [];
		for(var i in data){
			console.log("Inside testRedis");
			comments.push( JSON.parse( data[i] ) );
			console.log("data from redis: " + data[i]);
		}
		next(error, comments);
	});*/
	
    next(error);
  }
};

'use strict';



exports.action = {
  name:                   'getSceneInventory',
  description:            'I am an API method that will provide a list of scenery to load in the BabylonJS 3D scene.',
  blockedConnectionTypes: [],
  outputExample:          {},
  matchExtensionMimeType: false,
  version:                1.0,
  toDocument:             true,
  middleware:             [],

  inputs: {},

  run: function(api, data, next) {
    let error = null;
	
	
	data.response.ownAvatar = {};
	data.response.ownAvatar.folder = "images/";
	data.response.ownAvatar.meshName = "soccerPlayer.babylon";
	data.response.ownAvatar.meshNumber = 0;
	data.response.otherAvatars = [];
	api.chatRoom.roomStatus("movementUpdatesRoom", function(error, details){
		if (details.members) {
			Object.keys(details.members).forEach(function(key) {
				console.log(key, details[key]);
			});
		}
		
		var redis = api.redis.clients.client;
		var key = "user1";
		var data = "andrew";
		console.log("Inside getSceneInventory");
		redis.set(key, data, function(error){
			next(error);
		});
		next(error); //I'm unclear if this blocks the thread and makes things bad?? Since I am in a callback?? I'm not sure..
	});
	
  }
 
};

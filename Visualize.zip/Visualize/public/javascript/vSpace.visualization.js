"use strict";

var VSPACE = VSPACE || {};


VSPACE.visualization = function() {	
	this._canvas = null;
	this._engine = null;
	this._scene = null;
	
	this._myAvatar = null;
	this._currentCommand = VSPACE.constants.enumDirections.none;
	
	this._otherAvatars = null;
	this._lights = null;
	this._scenery = null;
	
	this._activeCamera = null;
	
	VSPACE.visualization.prototype.initialize = initializeVisualization(canvasName, chatMessageBoxName,chatBoxResponsesName);
	/*canvas: {},
	engine: {},
	scene: {},

	lights: [],
	scenery: [],
	activeCamera: {},
	
	myAvatar: {}, //will contain only me 3D body - me.
	currentCommand: VSPACE.constants.enumDirections.none, //This is the commands given by the user to go somewhere or do something. To begin with, there isn't any command given.
	
	otherAvatars:{}, //will be an object that holds all of the other characters.*/
};

/*
This function should be called one-time on start-up to set up the Babylon JS World.

Parameters:
canvasName: a string containing the name of the HTML canvas element id. We will attach the Babylon JS world to it.
chatMessageBox: a string containing the name of the HTML input box element. This is for disabling and enabling Babylon movements, among other things.
*/
//VSPACE.visualization.initialize = function(canvasName, chatMessageBoxName,chatBoxResponsesName){
function initializeVisualization (canvasName, chatMessageBoxName,chatBoxResponsesName){
	//Find correct HTML elements that will be needed later on:
//	VSPACE.visualization.canvas = document.querySelector(canvasName);
	this._canvas = document.querySelector(canvasName);
	VSPACE.constants.chatMessageBox = document.getElementById(chatMessageBoxName);
	VSPACE.constants.chatBoxResponses = document.getElementById(chatBoxResponsesName);
	
	console.log("In initializing function");
	//Set up the Babylon scene:
//	VSPACE.visualization.createScene(); 	
	//this.createScene();
	//VSPACE.visualization.engine.runRenderLoop(VSPACE.visualization.cyclicalUpdates);
//	VSPACE.visualization.enableKeyStrokeListener();	
	
	
	//Set up the event listeners:
	
	//When they are typing a chat message, we don't want Babylon to move our character around the screen.
//	VSPACE.constants.chatMessageBox.addEventListener("focus", VSPACE.visualization.disableKeyStrokeListener);
	
	//After the chat message has been sent, and they no longer have focus on
	//the message input box, we want to turn on listening for keys.
//	VSPACE.constants.chatMessageBox.addEventListener("blur", VSPACE.visualization.enableKeyStrokeListener);
	
	// Watch for browser/canvas resize events
//	window.addEventListener("resize", function () {
//		VSPACE.visualization.engine.resize();
//	});
};


/*
This function is essentially the standard BabylonJS method that you always see, and could
in fact drop into one of their online testing pages (well, more or less).
It basically loads in the scenery (including avatars), and gets everything prepared,
and then displays the scene.
*/
//VSPACE.visualization.createScene = function(){
function createScene() {
	// Load the BABYLON 3D engine
	VSPACE.visualization.engine = new BABYLON.Engine(VSPACE.visualization.canvas, true);		
	VSPACE.visualization.scene = new BABYLON.Scene(VSPACE.visualization.engine);
	// Change the scene background color to white.
	VSPACE.visualization.scene.clearColor = new BABYLON.Color3(1, 1, 1);
	// This creates a light, aiming 0,1,0 - to the sky.
	let light = new BABYLON.HemisphericLight("light1", new BABYLON.Vector3(0, 1, 0), VSPACE.visualization.scene);
	// Dim the light a small amount
	light.intensity = .5;
	// Let's try our built-in 'sphere' shape. Params: name, subdivisions, size, scene
	VSPACE.visualization.myAvatar = BABYLON.Mesh.CreateSphere("myAvatar", 16, 2, VSPACE.visualization.scene);
	let myAvatarMaterial = new BABYLON.StandardMaterial("myAvatarMaterial", VSPACE.visualization.scene);
	myAvatarMaterial.diffuseTexture = new BABYLON.Texture("images/beachball_diffuse.jpg", VSPACE.visualization.scene);
	VSPACE.visualization.myAvatar.material = myAvatarMaterial;
	// Move the sphere upward 1/2 its height
	VSPACE.visualization.myAvatar.position.y = 1;
	let ground = BABYLON.Mesh.CreateGround("ground1", 6, 6, 2, VSPACE.visualization.scene);
	let camera = new BABYLON.ArcRotateCamera("ArcRotateCamera", 0,0,0, BABYLON.Vector3.Zero(), VSPACE.visualization.scene);
	camera.setPosition(new BABYLON.Vector3(0, 10, -10));
	camera.attachControl(VSPACE.visualization.canvas, false);
	camera.setTarget(VSPACE.visualization.myAvatar.position);
	camera.inputs.clear();
	camera.inputs.addKeyboard();
	camera.inputs.attachInput(camera.inputs.attached.keyboard);
	//camera.inputs.addMouseMove();
	//camera.inputs.attachInput(camera.inputs.attached.mousemove);
	camera.inputs.addMouseWheel();
	camera.inputs.attachInput(camera.inputs.attached.mousewheel);
	VSPACE.visualization.activeCamera = camera;
	// Let's try our built-in 'ground' shape. Params: name, width, depth, subdivisions, scene

	VSPACE.visualization.engine.runRenderLoop(VSPACE.visualization.cyclicalUpdates);
	console.log("About to import mesh...");
	BABYLON.SceneLoader.ImportMesh("", "images/", "soccerPlayer.babylon", VSPACE.visualization.scene, function (newMeshes, particleSystems, skeletons) {
		console.log("Mesh apparently imported...");
		console.log("Mesh 0: " + newMeshes[0]);
		let oldMesh = VSPACE.visualization.scene.getMeshByName("myAvatar");
		VSPACE.visualization.myAvatar = newMeshes[0];
		oldMesh.dispose();
		oldMesh = null;
		VSPACE.visualization.myAvatar.name = ("myAvatar");
		console.log("Mesh 0: " + newMeshes[0]);
		//camera.setTarget(this.myAvatar.position);
	});
}

/*
This is the function that should be attached to the engine render loop and thus
will be updated cyclically (roughly 30 fps). (NOTE: This connection should be established
during initialization). This is standard BabylonJS practice.
So one way or another, all updates must be fed into this function.
*/
VSPACE.visualization.cyclicalUpdates = function(){
	VSPACE.visualization.updateOwnAvatarPosition();
	VSPACE.visualization.scene.render();
};
	
/*
This is one function, activated by various listeners,
that decides what, if anything, the user is trying to tell us.
It is basically looking for keyboard keys actively being pushed down.
*/
VSPACE.visualization.onKeyDown = function(evt){
	//alert("KeyDown");
	switch(evt.keyCode){
		case VSPACE.constants.enumDirectionKeys.keyUp:
			VSPACE.constants.keyStates.keyUp = true;
			if (VSPACE.constants.keyStates.keyLeft === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.northwest;
			} else if (VSPACE.constants.keyStates.keyRight === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.northeast;
			} else {
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.north;
			}
			break;
		case VSPACE.constants.enumDirectionKeys.keyLeft:
			VSPACE.constants.keyStates.keyLeft = true;
			if (VSPACE.constants.keyStates.keyUp === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.northwest;
			} else if (VSPACE.constants.keyStates.keyDown === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.southwest;
			} else {
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.west;
			}
			break;
		case VSPACE.constants.enumDirectionKeys.keyRight:
			VSPACE.constants.keyStates.keyRight = true;
			if (VSPACE.constants.keyStates.keyUp === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.northeast;
			} else if (VSPACE.constants.keyStates.keyDown === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.southeast;
			} else {
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.east;
			}
			break;
		case VSPACE.constants.enumDirectionKeys.keyDown:
			VSPACE.constants.keyStates.keyDown = true;
			if (VSPACE.constants.keyStates.keyLeft === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.southwest;
			} else if (VSPACE.constants.keyStates.keyRight === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.southeast;
			} else {
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.south;
			}
			break;
		case VSPACE.constants.enumDirectionKeys.keyJump:
			VSPACE.constants.keyStates.keyJump = true;
			VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.jump;
			break;
		case VSPACE.constants.enumDirectionKeys.keyKick:
			VSPACE.constants.keyStates.keyKick = true;
			VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.kick;
			break;
	}
	console.log('currentCommand: ' + VSPACE.visualization.currentCommand);
}

/*
This is one function, activated by various listeners,
that decides what, if anything, the user is trying to tell us.
It is basically looking for keyboard keys actively being released.
*/
VSPACE.visualization.onKeyUp = function(evt){
	//alert("KeyUp");		
	switch(evt.keyCode){
		case VSPACE.constants.enumDirectionKeys.keyUp:
			VSPACE.constants.keyStates.keyUp = false;
			if (VSPACE.constants.keyStates.keyLeft === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.west;
			} else if (VSPACE.constants.keyStates.keyRight === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.east;
			} else {
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.none;
			}
			break;
		case VSPACE.constants.enumDirectionKeys.keyLeft:
			VSPACE.constants.keyStates.keyLeft = false;
			if (VSPACE.constants.keyStates.keyUp === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.north;
			} else if (VSPACE.constants.keyStates.keyDown === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.south;
			} else {
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.none;
			}
			break;
		case VSPACE.constants.enumDirectionKeys.keyRight:
			VSPACE.constants.keyStates.keyRight = false;
			if (VSPACE.constants.keyStates.keyUp === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.north;
			} else if (VSPACE.constants.keyStates.keyDown === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.south;
			} else {
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.none;
			}
			break;
		case VSPACE.constants.enumDirectionKeys.keyDown:
			VSPACE.constants.keyStates.keyDown = false;
			if (VSPACE.constants.keyStates.keyLeft === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.west;
			} else if (VSPACE.constants.keyStates.keyRight === true){
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.east;
			} else {
				VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.none;
			}
			break;
		case VSPACE.constants.enumDirectionKeys.keyJump:
			VSPACE.constants.keyStates.keyJump = false;
			VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.none;
			break;
		case VSPACE.constants.enumDirectionKeys.keyKick:
			VSPACE.constants.keyStates.keyKick = false;
			VSPACE.visualization.currentCommand = VSPACE.constants.enumDirections.none;
			break;
	}
	console.log('currentCommand: ' + VSPACE.visualization.currentCommand);
}

/*
So in some situations, like when a user is trying to type a chat message,
we don't want to move the character around the screen as they type. So
we need to temporarily disable trapping for keyboard events by Babylon.
*/
VSPACE.visualization.disableKeyStrokeListener = function(){
	BABYLON.Tools.UnregisterTopRootEvents([{
		name: "keydown",
		handler: VSPACE.visualization.onKeyDown
	}, {
		name: "keyup",
		handler: VSPACE.visualization.onKeyUp
	}]);
}

/*
So in some situations, like when a user is trying to type a chat message,
we don't want to move the character around the screen as they type. So
we need to temporarily disable trapping for keyboard events by Babylon.
HOWEVER we need to turn it back on during normal operation (and also during
startup).
*/
VSPACE.visualization.enableKeyStrokeListener = function(){
	// Register events with the right Babylon function
	BABYLON.Tools.RegisterTopRootEvents([{
		name: "keydown",
		handler: VSPACE.visualization.onKeyDown
	}, {
		name: "keyup",
		handler: VSPACE.visualization.onKeyUp
	}]);
}

/*
This function takes a look at the current keyboard commands,
and updates our avatar accordingly.
*/
VSPACE.visualization.updateOwnAvatarPosition = function(){
	//This interprets user commands (like from keyboard),
	//and changes the position. It also fires off a chat room
	//message to all other occupants, so that they know our
	//position has been updated.
	switch(VSPACE.visualization.currentCommand){
		case VSPACE.constants.enumDirections.none:
			
			break;
		case VSPACE.constants.enumDirections.north:
			VSPACE.visualization.myAvatar.position.z += 1;
			VSPACE.connection.sendMovementMessage();
			break;
		case VSPACE.constants.enumDirections.northeast:
		
			break;
		case VSPACE.constants.enumDirections.east:
			VSPACE.visualization.myAvatar.position.x += 1;
			VSPACE.connection.sendMovementMessage();
			break;
		case VSPACE.constants.enumDirections.southeast:
		
			break;
		case VSPACE.constants.enumDirections.south:
			VSPACE.visualization.myAvatar.position.z -= 1;
			VSPACE.connection.sendMovementMessage();
			break;
		case VSPACE.constants.enumDirections.southwest:
		
			break;
		case VSPACE.constants.enumDirections.west:
			VSPACE.visualization.myAvatar.position.x -= 1;
			VSPACE.connection.sendMovementMessage();
			break;
		case VSPACE.constants.enumDirections.northwest:
		
			break;
		case VSPACE.constants.enumDirections.jump:
		
			break;
		case VSPACE.constants.enumDirections.kick:			
			VSPACE.visualization.scene.beginAnimation(VSPACE.visualization.myAvatar, 0, 100, false);
			break;
	}
}




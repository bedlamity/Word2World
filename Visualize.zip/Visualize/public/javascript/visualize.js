/*
	This is the place to put the companion client-side code to soccer.html.
	This code relies on the bab2AhClientManager and bab2AhWorldManager code for the underlying boiler plate code
	that is intended to be duplicated in other, real projects.
	In here should be project-specific (e.g. soccer-specific) code.
	NOTE: there is accompanying node.js/ ActionHero code that must run on the server.
*/

//This is the line that gets it all started.
window.addEventListener('load',  function(){
	vSpace = new VSpace("renderCanvas", "message", "chatBox");
	//vSpace.visualization.initialize("#renderCanvas", "message", "chatBox");
	console.log("We are loaded...");
	//VSPACE.connection.initialize();
});

//document.getElementById('messageForm').addEventListener('submit', function(e){ e.preventDefault(); VSPACE.connection.sendMessage(); }, false);
//Needs to be moved or upgraded to actually do something
document.getElementById('messageForm').addEventListener('submit', function(e){ e.preventDefault();}, false);

//window.addEventListener('load ', bab2AhMessageHandler({canvas: 'renderCanvas', chatBoxResponses: 'chatBox', chatBoxMessageToSend: 'message'}));

//document.getElementById('messageForm').addEventListener('submit', function(e){ e.preventDefault(); sendMessage(); }, false);
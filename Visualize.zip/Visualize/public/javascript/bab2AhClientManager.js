/*
BabylonJS is the 3D engine we are using.
ActionHero is the socket manager we are using. It provides a client code bundle,
as well as the server code. It is really good at passing messages ("chatting").
Our job is to a weave these two projects together so that we can
create a virtual world where different people can log in and see
everything. Each browser may be controlling a character, or there
can be objects controlled by the server. Either way we need messages
passed around to the participants of a room. These messages will
consist of announcements as to objects that should appear in the
space, and then announcements about their current state (position,
orientation, animation being played).
Other channels include a chat channel where participants can
write text to each other. There may be other channels eventually,
like streaming sound, but these are not implemented.

This is the client-side and will be given to the browser.
There is a corresponding server project that is basically an
ActionHero api server layered with our stuff.


TO USE:
Everything starts off by calling the function bab2AhMessageHandler(parameters).
You should call it after the main document has loaded.
This function will also start up the code inside the script bab2AhWorldManager
at the appropriate times.
*/

var VSPACE = VSPACE || {};

VSPACE.communication = {};

var client;

var canvas;
var chatBoxResponses;
var chatBoxMessageToSend;

/*
This is the main function that we need to call after the page loads.
It takes the parameters:
canvas: the id of the canvas tag to render the scene
chatBoxResponses: the id of the div where we can participants can chat.
chatBoxMessageToSend: the id of the inputbox tag where they type messages.
*/
var bab2AhMessageHandler = function(parameters){
	canvas = parameters.canvas;
	chatBoxResponses = parameters.chatBoxResponses;
	chatBoxMessageToSend = parameters.chatBoxMessageToSend;

	client = new ActionheroClient;

	client.on('connected',    function(){ console.log('connected!');}); 
	client.on('disconnected', function(){ console.log('disconnected :(')});
	client.on('error',        function(error){ console.log('error', error.stack) });
	client.on('reconnect',    function(){ console.log('reconnect') });
	client.on('reconnecting', function(){ console.log('reconnecting') });
	client.on('alert',        function(message){ alert( JSON.stringify(message) ) });
	client.on('api',          function(message){ alert( JSON.stringify(message) ) });
	client.on('welcome',      function(message){ appendMessage(message); });
	client.on('say',          function(message){ appendMessage(message); });

	client.connect(function(error, details){
		if( error != null){
		  console.log(error);
		} else {
			client.roomAdd("playerChatRoom", function(error){ 
			if (error){ console.log(error);} });
			document.getElementById("name").innerHTML = "<span style=\"color:#" + intToARGB(hashCode(client.id)) + "\">" + client.id + "</span>";
			client.roomAdd("movementUpdatesRoom", function(data){
				if (data.status === "OK") {
					//So this callback is performed once we are completely added to the room.
					//This means we can get in here and immediately send things.
					//loadBabylon(announceEntry);
					//announceEntry();
				} else {
					for (var property in data) {
						console.log(property + "=" + data[property]);
					}
				};
			});
		}
	});
}

	
    var appendMessage = function(message){
		console.log("in appendMessage function...");
      var s = "";
      s += "<pre>"
      if (message.welcome != null){
        s += "<div align=\"center\">*** " + message.welcome + " ***</div>";
		console.log("Welcome message found: " + message.welcome);
		//announceEntry(); //NOTE: moved to connected event emitter.
        <!--s += "<div align=\"center\"><img src=\"/public/logo/actionhero.png\" width=\"100\" /></div>";-->
      }else{
		console.log("message from: " + client.id); //message.from);
		if (message.room === "movementUpdatesRoom"){
			console.log("movementUpdatesRoom message received...");
			if (client.id != message.from){
				var newMovement = JSON.parse(message.message);
				if (newMovement.newClient === true) {
					//So this is a special message announcing a new player has entered the game.
					//So we need to create a new object for them.
					
					//So the only reason we are in here is because
					//somebody new has joined the world.
					//So create this avatar in our private local BabylonJS representation:
					otherAvatars[message.from] = BABYLON.Mesh.CreateSphere(message.from, 16, 2, scene);
					var otherAvatarMaterial = new BABYLON.StandardMaterial("otherAvatarMaterial", scene);
					otherAvatarMaterial.diffuseTexture = new BABYLON.Texture("images/beachball_diffuse.jpg", scene);
					otherAvatars[message.from].material = otherAvatarMaterial;
					otherAvatars[message.from].position.x = newMovement.x;
					otherAvatars[message.from].position.y = newMovement.y;
					otherAvatars[message.from].position.z = newMovement.z;
										
					console.log("new player entered the game. Sphere created...");
					//Passing on my information, since the new person will want to know all about us.
					reportMyInformation();
				} else if (newMovement.requestAllParticipants === true) {
					//So somebody wants to know who all is in here.
					//Likely this is because they just joined.
					//So we will go ahead and send them a message about ourselves.
					reportMyInformation();
				} else if (newMovement.updateStatus === true) {
					//Hmmm, I might be able to consolidate some of these things different messages, but for
					//now, this is a separate condition. Basically, we can check and 
					//see if this person exists. If they don't exist, we will add them.
					console.log("updateStatus message received. Here are the properties:");
					
					if (typeof otherAvatars[message.from] === "undefined") {
						console.log("An avatar we don't know about announced themselves, and so we added them.");
						otherAvatars[message.from] = BABYLON.Mesh.CreateSphere(message.from, 16, 2, scene);
						var otherAvatarMaterial = new BABYLON.StandardMaterial("otherAvatarMaterial", scene);
						otherAvatarMaterial.diffuseTexture = new BABYLON.Texture("images/beachball_diffuse.jpg", scene);
						otherAvatars[message.from].material = otherAvatarMaterial;
						otherAvatars[message.from].position.x = newMovement.x;
						otherAvatars[message.from].position.y = newMovement.y;
						otherAvatars[message.from].position.z = newMovement.z;						
					}
					else {
						console.log("Avatar updated their status, but we already had them, so we didn't update.");
					}
				} else {
					//So this is not a new player being announced. Instead we will try and
					//move the object that is associated with them.
					//If one doesn't exist, we should try and create one (eventually).
					otherAvatars[message.from].position.x = newMovement.x;
					otherAvatars[message.from].position.y = newMovement.y;
					otherAvatars[message.from].position.z = newMovement.z;
					console.log("Message from other player. I will process it...");
				}
			} else {
				console.log("self movement message. Will ignore it...");
			}
		} else {
			s += " " + formatTime(message.sentAt);
			s += "<span style=\"color:#" + intToARGB(hashCode(message.from)) + "\">"
			s += " [";
			if(message.me === true){ s += "<strong>"; }
			s += message.from;
			if(message.me === true){ s += "</strong>"; }
			s += "] ";
			s += "</span>"
			s += message.message;
			s += "</pre>"
			  var div = document.getElementById(chatBoxResponses);
			  div.innerHTML = s + div.innerHTML;
		}
      }
      
	  console.log("At end of appendMessage()...");
    }

    var sendMessage = function(){
      var div = document.getElementById("message");
      var message = div.value;
      div.value = "";
      client.say(client.rooms[0], message);
    }
	
	var sendMovementMessage = function(){
		var messageAsObject = {
			x: myAvatar.position.x,
			y: myAvatar.position.y,
			z: myAvatar.position.z
		};
		var message = JSON.stringify(messageAsObject);
		client.say(client.rooms[1], message);
		console.log("Sent movement message: " + message);
	}
	
	//This function announces to the group that
	//this client has just joined, and gives them
	//some basic information about her.
	var announceEntry = function(){
		console.log("I am requesting all other clients to tell me about themselves, and I tell them about me as well.");
		var messageAsObject = {
			newClient: true,
			id: client.id,
			body: 'sphere',
			x: myAvatar.position.x,
			y: myAvatar.position.y,
			z: myAvatar.position.z
		};
		var message = JSON.stringify(messageAsObject);
		client.say(client.rooms[1], message);	
	}
	
	//This function reports this avatars information to the
	//group. So this isn't when we are new to the group,
	//but rather somebody else wants to update their list. 
	//Likely this is because THEY are new and need to get
	//a good picture of the room.
	var reportMyInformation = function(){
		console.log("I am reporting my current information, because somebody asked for it.");
		var messageAsObject = {
			updateStatus: true,
			id: client.id,
			body: 'sphere',
			x: myAvatar.position.x,
			y: myAvatar.position.y,
			z: myAvatar.position.z
		};
		var message = JSON.stringify(messageAsObject);
		client.say(client.rooms[1], message);	
	}
	
	//Call this function to send out a group wide request for all
	//current participants. So basically when you first join the room,
	//you need to ask who all is here, and then you can build up
	//the appropriate visual image from the responses.
	var requestAllCurrentParticipants = function(){
		var messageAsObject = {
			requestAllParticipants: true
		}
		var message = JSON.stringify(messageAsObject);
		client.say(client.rooms[1], message);
	}
	
    var formatTime = function(timestamp){
      return new Date(timestamp).toLocaleTimeString()
    }

    function hashCode(str) { // java String#hashCode
        var hash = 0;
        for (var i = 0; i < str.length; i++) {
           hash = str.charCodeAt(i) + ((hash << 5) - hash);
        }
        return hash;
    }

    function intToARGB(i){
        var color =
          ((i>>24)&0xFF).toString(16) +
          ((i>>16)&0xFF).toString(16) +
          ((i>> 8)&0xFF).toString(16) +
          (i&0xFF).toString(16);
        return color.substring(0, 6);
    }

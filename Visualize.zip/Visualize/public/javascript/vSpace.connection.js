var VSPACE = VSPACE || {};


VSPACE.connection = {
	client: {}
}

VSPACE.connection.initialize = function(){
	console.log("Trying to start actionHero connection...");
	VSPACE.connection.client = new ActionheroClient;

	VSPACE.connection.client.on('connected',    function(){ console.log('connected!');}); 
	VSPACE.connection.client.on('disconnected', function(){ console.log('disconnected :(')});
	VSPACE.connection.client.on('error',        function(error){ console.log('error', error.stack) });
	VSPACE.connection.client.on('reconnect',    function(){ console.log('reconnect') });
	VSPACE.connection.client.on('reconnecting', function(){ console.log('reconnecting') });
	VSPACE.connection.client.on('alert',        function(message){ alert( JSON.stringify(message) ) });
	VSPACE.connection.client.on('api',          function(message){ console.log(message); });
	VSPACE.connection.client.on('welcome',      function(message){ VSPACE.connection.appendMessage(message); });
	VSPACE.connection.client.on('say',          function(message){ VSPACE.connection.appendMessage(message); });	
	
	VSPACE.connection.client.connect(function(error, details){
		if( error != null){
		  console.log(error);
		} else {
			VSPACE.connection.client.roomAdd("playerChatRoom", function(data){ 
				if (data.status === "OK") {
					document.getElementById("name").innerHTML = "<span style=\"color:#" + VSPACE.connection.intToARGB(VSPACE.connection.hashCode(VSPACE.connection.client.id)) + "\">" + VSPACE.connection.client.id + "</span>";
					console.log("Added player chat room...");
					
					//NOTE: we can only add one room at a time, so that is why these are nested...
					VSPACE.connection.client.roomAdd("movementUpdatesRoom", function(data){
						if (data.status === "OK") {
							//So this callback is performed once we are completely added to the room.
							//This means we can get in here and immediately send things.
							//loadBabylon(announceEntry);
							console.log("Added movement update room...");
							VSPACE.connection.announceEntry();
						} else {
							console.log(data.status);
						};
					});
				} else {
					console.log("Adding player chat room failed....");
					console.log(data.status);
				}
			});
		}
	});
}

VSPACE.connection.appendMessage = function(message){
	//console.log("in appendMessage function...");
      var s = "";
      s += "<pre>"
      if (message.welcome != null){
        s += "<div align=\"center\">*** " + message.welcome + " ***</div>";
		console.log("Welcome message found: " + message.welcome);
		//announceEntry(); //NOTE: moved to connected event emitter.
        <!--s += "<div align=\"center\"><img src=\"/public/logo/actionhero.png\" width=\"100\" /></div>";-->
      }else{
		//console.log("message from: " + VSPACE.connection.client.id); //message.from);
		if (message.room === "movementUpdatesRoom"){
			console.log("movementUpdatesRoom message received...");
			if (VSPACE.connection.client.id != message.from){
				var newMovement = JSON.parse(message.message);
				if (newMovement.newClient === true) {
					//So this is a special message announcing a new player has entered the game.
					//So we need to create a new object for them.
					
					//So the only reason we are in here is because
					//somebody new has joined the world.
					//So create this avatar in our private local BabylonJS representation:
					VSPACE.visualization.otherAvatars[message.from] = new BABYLON.Mesh.CreateSphere(message.from, 16, 2, VSPACE.visualization.scene);
					var otherAvatarMaterial = new BABYLON.StandardMaterial("otherAvatarMaterial", VSPACE.visualization.scene);
					otherAvatarMaterial.diffuseTexture = new BABYLON.Texture("images/beachball_diffuse.jpg", VSPACE.visualization.scene);
					VSPACE.visualization.otherAvatars[message.from].material = otherAvatarMaterial;
					VSPACE.visualization.otherAvatars[message.from].position.x = newMovement.x;
					VSPACE.visualization.otherAvatars[message.from].position.y = newMovement.y;
					VSPACE.visualization.otherAvatars[message.from].position.z = newMovement.z;
										
					console.log("new player entered the game. Sphere created...");
					//Passing on my information, since the new person will want to know all about us.
					VSPACE.connection.reportMyInformation();
				} else if (newMovement.requestAllParticipants === true) {
					//So somebody wants to know who all is in here.
					//Likely this is because they just joined.
					//So we will go ahead and send them a message about ourselves.
					reportMyInformation();
				} else if (newMovement.updateStatus === true) {
					//Hmmm, I might be able to consolidate some of these things different messages, but for
					//now, this is a separate condition. Basically, we can check and 
					//see if this person exists. If they don't exist, we will add them.
					console.log("updateStatus message received. Here are the properties:");
					
					if (typeof VSPACE.visualization.otherAvatars[message.from] === "undefined") {
						console.log("An avatar we don't know about announced themselves, and so we added them.");
						VSPACE.visualization.otherAvatars[message.from] = BABYLON.Mesh.CreateSphere(message.from, 16, 2, VSPACE.visualization.scene);
						var otherAvatarMaterial = new BABYLON.StandardMaterial("otherAvatarMaterial", VSPACE.visualization.scene);
						otherAvatarMaterial.diffuseTexture = new BABYLON.Texture("images/beachball_diffuse.jpg", VSPACE.visualization.scene);
						VSPACE.visualization.otherAvatars[message.from].material = otherAvatarMaterial;
						VSPACE.visualization.otherAvatars[message.from].position.x = newMovement.x;
						VSPACE.visualization.otherAvatars[message.from].position.y = newMovement.y;
						VSPACE.visualization.otherAvatars[message.from].position.z = newMovement.z;						
					}
					else {
						console.log("Avatar updated their status, but we already had them, so we didn't update.");
					}
				} else {
					//So this is not a new player being announced. Instead we will try and
					//move the object that is associated with them.
					//If one doesn't exist, we should try and create one (eventually).
					VSPACE.visualization.otherAvatars[message.from].position.x = newMovement.x;
					VSPACE.visualization.otherAvatars[message.from].position.y = newMovement.y;
					VSPACE.visualization.otherAvatars[message.from].position.z = newMovement.z;
					console.log("Message from other player. I will process it...");
				}
			} else {
				console.log("self movement message. Will ignore it...");
			}
		} else {
			s += " " + VSPACE.connection.formatTime(message.sentAt);
			s += "<span style=\"color:#" + VSPACE.connection.intToARGB(VSPACE.connection.hashCode(message.from)) + "\">"
			s += " [";
			if(message.me === true){ s += "<strong>"; }
			s += message.from;
			if(message.me === true){ s += "</strong>"; }
			s += "] ";
			s += "</span>"
			s += message.message;
			s += "</pre>"
			  //var div = document.getElementById(VSPACE.constants.chatBoxResponses);
			  //div.innerHTML = s + div.innerHTML;
			  VSPACE.constants.chatBoxResponses.innerHTML = s + VSPACE.constants.chatBoxResponses.innerHTML;
			  console.log("Chat message should have been posted...");
		}
      }
      
	  console.log("At end of appendMessage()...");
    }



VSPACE.connection.sendMessage = function(){
		var div = document.getElementById("message");
		var message = div.value;
		div.value = "";
		VSPACE.connection.client.say(VSPACE.connection.client.rooms[0], message);
    }
	
VSPACE.connection.sendMovementMessage = function(){
		var messageAsObject = {
//			x: VSPACE.visualization.myAvatar.position.x,
//			y: VSPACE.visualization.myAvatar.position.y,
//			z: VSPACE.visualization.myAvatar.position.z
		};
		var message = JSON.stringify(messageAsObject);
		VSPACE.connection.client.say(VSPACE.connection.client.rooms[1], message);
		console.log("Sent movement message: " + message);
	}


	
	//This function announces to the group that
	//this client has just joined, and gives them
	//some basic information about her.
VSPACE.connection.announceEntry = function(){
		console.log("I am requesting all other clients to tell me about themselves, and I tell them about me as well.");
		var messageAsObject = {
			newClient: true,
			id: VSPACE.connection.client.id,
			body: 'sphere',
//			x: VSPACE.visualization.myAvatar.position.x,
//			y: VSPACE.visualization.myAvatar.position.y,
//			z: VSPACE.visualization.myAvatar.position.z
		};
		var message = JSON.stringify(messageAsObject);
//		VSPACE.connection.client.say(VSPACE.connection.client.rooms[1], message);	
	}
	
	//This function reports this avatars information to the
	//group. So this isn't when we are new to the group,
	//but rather somebody else wants to update their list. 
	//Likely this is because THEY are new and need to get
	//a good picture of the room.
VSPACE.connection.reportMyInformation = function(){
		console.log("I am reporting my current information, because somebody asked for it.");
		var messageAsObject = {
			updateStatus: true,
			id: VSPACE.connection.client.id,
			body: 'sphere',
//			x: VSPACE.visualization.myAvatar.position.x,
//			y: VSPACE.visualization.myAvatar.position.y,
//			z: VSPACE.visualization.myAvatar.position.z
		};
		var message = JSON.stringify(messageAsObject);
//		VSPACE.connection.client.say(VSPACE.connection.client.rooms[1], message);	
	}
	
	//Call this function to send out a group wide request for all
	//current participants. So basically when you first join the room,
	//you need to ask who all is here, and then you can build up
	//the appropriate visual image from the responses.
VSPACE.connection.requestAllCurrentParticipants = function(){
		var messageAsObject = {
			requestAllParticipants: true
		}
		var message = JSON.stringify(messageAsObject);
//		VSPACE.connection.client.say(VSPACE.connection.client.rooms[1], message);
	}
	
VSPACE.connection.formatTime = function(timestamp){
      return new Date(timestamp).toLocaleTimeString()
    }

VSPACE.connection.hashCode = function(str) { // java String#hashCode
        var hash = 0;
        for (var i = 0; i < str.length; i++) {
           hash = str.charCodeAt(i) + ((hash << 5) - hash);
        }
        return hash;
    }

VSPACE.connection.intToARGB = function(i){
        var color =
          ((i>>24)&0xFF).toString(16) +
          ((i>>16)&0xFF).toString(16) +
          ((i>> 8)&0xFF).toString(16) +
          (i&0xFF).toString(16);
        return color.substring(0, 6);
    }
	
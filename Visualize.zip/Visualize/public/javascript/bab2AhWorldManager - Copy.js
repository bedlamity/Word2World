/*
	There is another file called "bab2AhClientManager" that is responsible for
	interpreting messages from the server, finding out what needs to be loaded from the server,
	and passing messages to the server.
	
	This file here is more responsible for handling the actual 3D world in this particular browser.
	So it's job is to load the babylon mesh files (the ones that it is told to load),
	and it is responsible moving things around as needed, and it is responsible for interpreting
	keyboard and mouse commands, and so on. You might say that this file interacts with BabylonJS
	and bab2AhClientManager, while the other file interacts with ActionHeroJS and this file (bab2AhWorldManager).
*/




/*
function loadBabylon(callback){
var myAvatar; //will contain only me 3D body - me.
var otherAvatars = {}; //will be an object that holds all of the other characters.
var scene;


// Get the canvas element from our HTML below
var canvas = document.querySelector("#renderCanvas");
// Load the BABYLON 3D engine
var engine = new BABYLON.Engine(canvas, true);




// -------------------------------------------------------------
// Here begins a function that we will 'call' just after it's built
var createScene = function () {
	 // Now create a basic Babylon Scene object
	 //var scene = new BABYLON.Scene(engine);
	 scene = new BABYLON.Scene(engine);
	 // Change the scene background color to green.
	 scene.clearColor = new BABYLON.Color3(1, 1, 1);
	 // This creates and positions a free camera
	 //var camera = new BABYLON.FreeCamera("camera1", new BABYLON.Vector3(0, 5, -10), scene);
	 // This targets the camera to scene origin
	 //camera.setTarget(BABYLON.Vector3.Zero());
	 // This attaches the camera to the canvas
	 //camera.attachControl(canvas, false);
	 // This creates a light, aiming 0,1,0 - to the sky.
	 var light = new BABYLON.HemisphericLight("light1", new BABYLON.Vector3(0, 1, 0), scene);
	 // Dim the light a small amount
	 light.intensity = .5;
	 // Let's try our built-in 'sphere' shape. Params: name, subdivisions, size, scene
	 myAvatar = BABYLON.Mesh.CreateSphere("myAvatar", 16, 2, scene);
	 var myAvatarMaterial = new BABYLON.StandardMaterial("myAvatarMaterial", scene);
	 myAvatarMaterial.diffuseTexture = new BABYLON.Texture("images/beachball_diffuse.jpg", scene);
	 myAvatar.material = myAvatarMaterial;
	 // Move the sphere upward 1/2 its height
	 myAvatar.position.y = 1;
	 // Let's try our built-in 'ground' shape. Params: name, width, depth, subdivisions, scene
	 var camera = new BABYLON.ArcRotateCamera("ArcRotateCamera", 0,0,0, BABYLON.Vector3.Zero(), scene);
	 camera.setPosition(new BABYLON.Vector3(0, 10, -10));
	 camera.attachControl(canvas, false);
	 camera.setTarget(myAvatar.position);
	 camera.inputs.clear();
	 camera.inputs.addKeyboard();
	 camera.inputs.attachInput(camera.inputs.attached.keyboard);
	 //camera.inputs.addMouseMove();
	 //camera.inputs.attachInput(camera.inputs.attached.mousemove);
	 camera.inputs.addMouseWheel();
	 camera.inputs.attachInput(camera.inputs.attached.mousewheel);
	 var ground = BABYLON.Mesh.CreateGround("ground1", 6, 6, 2, scene);
	 // Leave this function
	 return scene;
}; // End of createScene function
// -------------------------------------------------------------
// Now, call the createScene function that you just finished creating
var scene = createScene();

//This function needs to be called at some point to start up the Babylon scene.
//It is expected that it will be called from a function in bab2AhClientManager.js 
//after the action hero connection to the server is established.
/*var initializeBabylon = function () {
	scene = createScene();
	// Register a render loop to repeatedly render the scene
	cycleUpdate();

}*/

  
//A lot of this comes from the great tutorial at 
//http://www.spritehand.com/p/projects.html
//with the code being at:
//http://babylonplayground.azurewebsites.net/babyoncharacterwalk/
//A couple of big differences are we do this without babylon.gamefx, which may be obsolete??
//And we are connecting in to the Node.js backend called ActionHero, to get multiplayer capabilities.

//This is where you specify which keys do what things.
//Currently, these are the WASD keys, with control to kick, and space to jump
var enumDirectionKeys = {
	keyNone: 0,
	keyUp: 87,
	keyLeft: 65,
	keyRight: 68,
	keyDown: 83,
	keyJump: 32, 
	keyKick: 17
}

//Eventually we decipher the commands the user gives and combines them
//into a coherent action. So we can choose one of the following:
var enumDirections = {
	none: 0,
	north: 1,
	northeast: 2,
	east: 3,
	southeast: 4,
	south: 5,
	southwest: 6,
	west: 7,
	northwest: 8,
	jump: 9,
	kick: 10
}
var currentCommand = enumDirections.none;

// key states
//So keyboard buttons get pushed, and we keep track of them.
//true means it is currently pushed down.
//false means it is currently not pushed down (released).
var keyStates = {
	keyUp: false,
	keyLeft: false,
	keyRight: false,
	keyDown: false,
	keyJump: false
}
	
var onKeyDown = function(evt){
	//alert("KeyDown");
	switch(evt.keyCode){
		case enumDirectionKeys.keyUp:
			keyStates.keyUp = true;
			if (keyStates.keyLeft === true){
				currentCommand = enumDirections.northwest;
			} else if (keyStates.keyRight === true){
				currentCommand = enumDirections.northeast;
			} else {
				currentCommand = enumDirections.north;
			}
			break;
		case enumDirectionKeys.keyLeft:
			keyStates.keyLeft = true;
			if (keyStates.keyUp === true){
				currentCommand = enumDirections.northwest;
			} else if (keyStates.keyDown === true){
				currentCommand = enumDirections.southwest;
			} else {
				currentCommand = enumDirections.west;
			}
			break;
		case enumDirectionKeys.keyRight:
			keyStates.keyRight = true;
			if (keyStates.keyUp === true){
				currentCommand = enumDirections.northeast;
			} else if (keyStates.keyDown === true){
				currentCommand = enumDirections.southeast;
			} else {
				currentCommand = enumDirections.east;
			}
			break;
		case enumDirectionKeys.keyDown:
			keyStates.keyDown = true;
			if (keyStates.keyLeft === true){
				currentCommand = enumDirections.southwest;
			} else if (keyStates.keyRight === true){
				currentCommand = enumDirections.southeast;
			} else {
				currentCommand = enumDirections.south;
			}
			break;
		case enumDirectionKeys.keyJump:
			keyStates.keyJump = true;
			currentCommand = enumDirections.jump;
			break;
		case enumDirectionKeys.keyKick:
			keyStates.keyKick = true;
			currentCommand = enumDirections.kick;
			break;
	}
	console.log('currentCommand: ' + currentCommand);
}

var onKeyUp = function(evt){
	//alert("KeyUp");		
	switch(evt.keyCode){
		case enumDirectionKeys.keyUp:
			keyStates.keyUp = false;
			if (keyStates.keyLeft === true){
				currentCommand = enumDirections.west;
			} else if (keyStates.keyRight === true){
				currentCommand = enumDirections.east;
			} else {
				currentCommand = enumDirections.none;
			}
			break;
		case enumDirectionKeys.keyLeft:
			keyStates.keyLeft = false;
			if (keyStates.keyUp === true){
				currentCommand = enumDirections.north;
			} else if (keyStates.keyDown === true){
				currentCommand = enumDirections.south;
			} else {
				currentCommand = enumDirections.none;
			}
			break;
		case enumDirectionKeys.keyRight:
			keyStates.keyRight = false;
			if (keyStates.keyUp === true){
				currentCommand = enumDirections.north;
			} else if (keyStates.keyDown === true){
				currentCommand = enumDirections.south;
			} else {
				currentCommand = enumDirections.none;
			}
			break;
		case enumDirectionKeys.keyDown:
			keyStates.keyDown = false;
			if (keyStates.keyLeft === true){
				currentCommand = enumDirections.west;
			} else if (keyStates.keyRight === true){
				currentCommand = enumDirections.east;
			} else {
				currentCommand = enumDirections.none;
			}
			break;
		case enumDirectionKeys.keyJump:
			keyStates.keyJump = false;
			currentCommand = enumDirections.none;
			break;
		case enumDirectionKeys.keyKick:
			keyStates.keyKick = false;
			currentCommand = enumDirections.none;
			break;
	}
	console.log('currentCommand: ' + currentCommand);
}

//So whenever we click to send a chat message, we don't want to move
//the character around the screen at the same time. So we need to stop
//listening temporarily for keypresses
document.getElementById("message").addEventListener("focus",function(){
	// Register events with the right Babylon function
	BABYLON.Tools.UnregisterTopRootEvents([{
		name: "keydown",
		handler: onKeyDown
	}, {
		name: "keyup",
		handler: onKeyUp
	}]);
});

//After the message has been sent, and they no longer have focus on
//the message input box, we want to turn on listening for keys.
document.getElementById("message").addEventListener("blur",function(){
	// Register events with the right Babylon function
	BABYLON.Tools.RegisterTopRootEvents([{
		name: "keydown",
		handler: onKeyDown
	}, {
		name: "keyup",
		handler: onKeyUp
	}]);
});


//This turns on key listening right from the get go, so that
//we can can move the character around the screen.
//(Only if the click in the message box do we want to stop
//moving the character around the screen. In this case, we would
//disable it.
BABYLON.Tools.RegisterTopRootEvents([{
	name: "keydown",
	handler: onKeyDown
}, {
	name: "keyup",
	handler: onKeyUp
}]);
 
engine.runRenderLoop(function () {

	//This interprets user commands (like from keyboard),
	//and changes the position. It also fires off a chat room
	//message to all other occupants, so that they know our
	//position has been updated.
	switch(currentCommand){
		case enumDirections.none:
			
			break;
		case enumDirections.north:
			myAvatar.position.z += 1;
			sendMovementMessage();
			break;
		case enumDirections.northeast:
		
			break;
		case enumDirections.east:
			myAvatar.position.x += 1;
			sendMovementMessage();
			break;
		case enumDirections.southeast:
		
			break;
		case enumDirections.south:
			myAvatar.position.z -= 1;
			sendMovementMessage();
			break;
		case enumDirections.southwest:
		
			break;
		case enumDirections.west:
			myAvatar.position.x -= 1;
			sendMovementMessage();
			break;
		case enumDirections.northwest:
		
			break;
		case enumDirections.jump:
		
			break;
		case enumDirections.kick:
		
			break;
	}
	scene.render(myAvatar, otherAvatars, scene);
});

// Watch for browser/canvas resize events
window.addEventListener("resize", function () {
	engine.resize();
});

callback();
}*/
var VSPACE = VSPACE || {};


VSPACE.constants = {
	chatMessageBox: {}, //This is the text chatbox HTML element. We need this at various times to send messages.
	chatBoxResponses: {}, //This is the text chatbox HTML where all of the chat messages go that are received.

	//This is where you specify which keys do what things.
	//Currently, these are the WASD keys, with control to kick, and space to jump
	enumDirectionKeys: {
		keyNone: 0,
		keyUp: 87,
		keyLeft: 65,
		keyRight: 68,
		keyDown: 83,
		keyJump: 32, 
		keyKick: 17
	},

	//Eventually we decipher the commands the user gives and combines them
	//into a coherent action. So we can choose one of the following:
	enumDirections: {
		none: 0,
		north: 1,
		northeast: 2,
		east: 3,
		southeast: 4,
		south: 5,
		southwest: 6,
		west: 7,
		northwest: 8,
		jump: 9,
		kick: 10
	},

	// key states
	//So keyboard buttons get pushed, and we keep track of them.
	//true means it is currently pushed down.
	//false means it is currently not pushed down (released).
	keyStates: {
		keyUp: false,
		keyLeft: false,
		keyRight: false,
		keyDown: false,
		keyJump: false
	}
};
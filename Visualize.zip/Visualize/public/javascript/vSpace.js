/*
One master class means one namespace, and thus less chance of polluting
and messing up other code.
*/
class VSpace {
	constructor (canvasName, messageBoxName, chatBoxName) {
	
		this.defines = new VSpace_Defines(messageBoxName, chatBoxName, this);
		this.events = new VSpace_Events();
		this.commands = new VSpace_Commands(this);
		this.visualize = new VSpace_Visualize(canvasName, this);
		this.connection = new VSpace_Connection(this);
			
		console.log("Finished constructing VSpace...");
	}
}

/*
This is intended to be a private sub-class of VSpace.
It is responsible for making things display on the screen,
as well as for animating things.
It is intended that the "Connection" subclass will interface with
the back-end, and interpret messages that are passed on to this class.
These message will tell it what and where to display things.
*/
class VSpace_Visualize {
	constructor(canvasName, parent){
		this.parent = parent;
		
		this._canvas = document.getElementById(canvasName);
		
		this._engine = new Object();
		this._scene = new Object();

		this._myAvatar = new Object();
		this._currentCommand = new Object(); //this.parent.defines.DIRECTIONS.none;

		this._otherAvatars = new Object();
		this._lights = [];
		this._scenery = [];

		this._activeCamera = new Object();	
		
		
		this.parent.events.subscribeToEvent("getSceneInventory", (data)=>this._createScene(data));
		//this._createScene();
		console.log("Inside Visualize constructor...");
	}
	
	/*
	So this should be a callback that is run on start-up. Basically a message will be passed from the 
	Connection object (an event raised), and it should contain the necessary data to create the scene.
	So scenery, avatars, own avatar, etc should be loaded in, etc.
	*/	
	_createScene(data) {
		// Load the BABYLON 3D engine
		this._engine = new BABYLON.Engine(this._canvas, true);		
		this._scene = new BABYLON.Scene(this._engine);
		// Change the scene background color to white.
		this._scene.clearColor = new BABYLON.Color3(1, 1, 1);
		// This creates a light, aiming 0,1,0 - to the sky.
		let light = new BABYLON.HemisphericLight("light1", new BABYLON.Vector3(0, 1, 0), this._scene);
		// Dim the light a small amount
		light.intensity = .5;
		// Let's try our built-in 'sphere' shape. Params: name, subdivisions, size, scene
		this._myAvatar = BABYLON.Mesh.CreateSphere("myAvatar", 16, 2, this._scene);
		let myAvatarMaterial = new BABYLON.StandardMaterial("myAvatarMaterial", this._scene);
		myAvatarMaterial.diffuseTexture = new BABYLON.Texture("images/beachball_diffuse.jpg", this._scene);
		this._myAvatar.material = myAvatarMaterial;
		// Move the sphere upward 1/2 its height
		this._myAvatar.position.y = 1;
		let ground = BABYLON.Mesh.CreateGround("ground1", 6, 6, 2, this._scene);
		let camera = new BABYLON.ArcRotateCamera("ArcRotateCamera", 0,0,0, BABYLON.Vector3.Zero(), this._scene);
		camera.setPosition(new BABYLON.Vector3(0, 10, -10));
		camera.attachControl(this._canvas, false);
		camera.setTarget(this._myAvatar.position);
		camera.inputs.clear();
		camera.inputs.addKeyboard();
		camera.inputs.attachInput(camera.inputs.attached.keyboard);
		//camera.inputs.addMouseMove();
		//camera.inputs.attachInput(camera.inputs.attached.mousemove);
		camera.inputs.addMouseWheel();
		camera.inputs.attachInput(camera.inputs.attached.mousewheel);
		this._activeCamera = camera;
		// Let's try our built-in 'ground' shape. Params: name, width, depth, subdivisions, scene

		this._establishCyclicalUpdates();
		console.log("About to import mesh...");
		
		//let scene = this._scene;
		let that = this;
		//console.log("In scene, from message.");
		//console.log(data.ownAvatar.meshName);
		BABYLON.SceneLoader.ImportMesh("", data.ownAvatar.folder, data.ownAvatar.meshName, this._scene, (newMeshes, particleSystems, skeletons) => {
			//console.log("In scene, from message.");
			//console.log(data.ownAvatar.meshName);
			let oldMesh = this._scene.getMeshByName("myAvatar");
			this._myAvatar = newMeshes[0];
			oldMesh.dispose();
			oldMesh = null;
			this._myAvatar.name = ("myAvatar");
			camera.setTarget(this._myAvatar.position);
			console.log("Mesh imported...");
			/*let oldMesh = that._scene.getMeshByName("myAvatar");
			that._myAvatar = newMeshes[0];
			oldMesh.dispose();
			oldMesh = null;
			this._myAvatar.name = ("myAvatar");
			camera.setTarget(this._myAvatar.position);
			console.log("Mesh imported...");*/
		});
		
		this.parent.events.subscribeToEvent("currentCommand", (currentCommand)=>this._updateOwnAvatarPosition(currentCommand));
		
		// Watch for browser/canvas resize events
		window.addEventListener("resize", function () {
			that._engine.resize();
		});
	}	
	
	/*
	This is the function that should be attached to the engine render loop and thus
	will be updated cyclically (roughly 30 fps). (NOTE: This connection should be established
	during initialization). This is standard BabylonJS practice.
	So one way or another, all updates must be fed into this function.
	*/
	_establishCyclicalUpdates (){
		//this.parent.visualize.updateOwnAvatarPosition();
		//this.scene.render();
		let scene = this._scene;
		var that = this;
		this._engine.runRenderLoop(function (){
			//that._updateOwnAvatarPosition();
			scene.render();
		});
	}
	
	/*
	This function takes a look at the current keyboard commands,
	and updates our avatar accordingly.
	*/
	_updateOwnAvatarPosition(currentCommand){
		//This interprets user commands (like from keyboard),
		//and changes the position. It also fires off a chat room
		//message to all other occupants, so that they know our
		//position has been updated.
		var DEF = this.parent.defines;
		switch(currentCommand){
			case DEF.DIRECTIONS.NONE:
				break;
			case DEF.DIRECTIONS.NORTH:
				this._myAvatar.position.z += 1;
				//this.parent.connection._sendMovementMessage();
				
				break;
			case DEF.DIRECTIONS.NORTHEAST:
			
				break;
			case DEF.DIRECTIONS.EAST:
				this._myAvatar.position.x += 1;
				//this.parent.connection._sendMovementMessage();
				break;
			case DEF.DIRECTIONS.SOUTHEAST:
			
				break;
			case DEF.DIRECTIONS.SOUTH:
				this._myAvatar.position.z -= 1;
				//this.parent.connection._sendMovementMessage();
				break;
			case DEF.DIRECTIONS.SOUTHWEST:
			
				break;
			case DEF.DIRECTIONS.WEST:
				this._myAvatar.position.x -= 1;
				//this.parent.connection._sendMovementMessage();
				break;
			case DEF.DIRECTIONS.NORTHWEST:
			
				break;
			case DEF.DIRECTIONS.JUMP:
			
				break;
			case DEF.DIRECTIONS.KICK:			
				this._scene.beginAnimation(this._myAvatar, 0, 100, false);
				break;
		}
	}
	
}



/*
This is intended to be a private sub-class of VSpace.
It is responsible for establishing a connection, preferably WebSocket-based,
to the server(via ActionHeroJS). It then interprets signals from the Visualize
and Commands objects, and passes these messages to the server, as well as receiving messages
from the server and interpreting them for the Visualize object.
*/
class VSpace_Connection {
	constructor(parent){	
		this.parent = parent;
		var test = 2;
		this.test = 3;
		console.log("Inside Connection constructor...");
		
		console.log("Trying to start actionHero connection...");
		this._client = new ActionheroClient;
		var that = this;
		this._client.on('connected',    function(){ console.log('connected!');}); 
		this._client.on('disconnected', function(){ console.log('disconnected :(')});
		this._client.on('error',        function(error){ console.log('error', error.stack) });
		this._client.on('reconnect',    function(){ console.log('reconnect') });
		this._client.on('reconnecting', function(){ console.log('reconnecting') });
		this._client.on('alert',        function(message){ alert( JSON.stringify(message) ) });
		this._client.on('api',          function(message){ console.log(message); });
		//this._client.on('welcome',      function(message){ this._processNewMessage(message); });
		//this._client.on('welcome',      this._processNewMessage(message), that);
		//this._client.on('welcome', () => console.log("Welcome + local variable: " + test));
		this._client.on('welcome', (message) => that._processNewMessage(message));
		//this._client.on('say',          function(message){ this._processNewMessage(message); });	
		//this._client.on('say',          this._processNewMessage(message), that);	
		//WORKS:
		//this._client.on('say', (message) => {console.log("Say + local variable: " + that.test + " message: " + JSON.stringify(message));});
		this._client.on('say', (message) => that._processNewMessage(message));
		
		
		this._client.connect(function(error, details){
			if( error != null){
			  console.log(error);
			} else {
				that._client.action("getSceneInventory", function(data) {
					that._client.action("testRedis", function(data){});
					console.log("Scenery arrived.");
					console.log(data.ownAvatar.folder);
					console.log(data.ownAvatar.meshName);
					that.parent.events.fireOffEvent("getSceneInventory", data);
				
					that._client.roomAdd("playerChatRoom", function(data){ 
						if (data.status === "OK") {
							document.getElementById("name").innerHTML = "<span style=\"color:#" + that._intToARGB(that._hashCode(that._client.id)) + "\">" + that._client.id + "</span>";
							console.log("Added player chat room...");
							
							//NOTE: we can only add one room at a time, so that is why these are nested...
							that._client.roomAdd("movementUpdatesRoom", function(data){
								if (data.status === "OK") {
									//So this callback is performed once we are completely added to the room.
									//This means we can get in here and immediately send things.
									//loadBabylon(announceEntry);
									console.log("Added movement update room...");
									that._announceEntry();
								} else {
									console.log(data.status);
								};
							});
						} else {
							console.log("Adding player chat room failed....");
							console.log(data.status);
						}
					});
				});
			}
		});
		
		this.parent.events.subscribeToEvent("currentCommand", (currentCommand)=>this.commandEventUpdated(currentCommand));
	}
	
	/*
	In the constructor, set-up this function as a callback function whenever
	the command event is reported (that is whenever the user pushes a keyboard
	button to move (or touch event, etc)).
	parameters:
	command: object - the interpreted command given
	*/
	commandEventUpdated(currentCommand){
		//console.log("Communication object received event that user pushed a button.");
		//console.log("current command(from inside event subscriber: " + command);
		this._sendMovementMessageV2(currentCommand);
	}
	
	/*
	So after the initial welcome message from the server confirming our connection,
	we need to immediately ask for the scenery to load.
	*/
	_getScenery(message){
	
	}
	
	
	/*
	This is the main function when "chat" messages arrive. We need figure out who is from
	and what it is. Then we need to figure out how to handle it.
	*/
	_processNewMessage(message) {
		console.log("in appendMessage function: " + message);
		var s = "";
		s += "<pre>"
		if (message.welcome != null){
		s += "<div align=\"center\">*** " + message.welcome + " ***</div>";
		console.log("Welcome message found: " + message.welcome);
		//announceEntry(); //NOTE: moved to connected event emitter.
		<!--s += "<div align=\"center\"><img src=\"/public/logo/actionhero.png\" width=\"100\" /></div>";-->
		}else{
			console.log("message from: " + this._client.id); //message.from);
			if (message.room === "movementUpdatesRoom"){
				console.log("movementUpdatesRoom message received...");
				if (this._client.id != message.from){
					var newMovement = JSON.parse(message.message);
					if (newMovement.newClient === true) {
						//So this is a special message announcing a new player has entered the game.
						//So we need to create a new object for them.
						
						//So the only reason we are in here is because
						//somebody new has joined the world.
						//So create this avatar in our private local BabylonJS representation:
						this.parent.visualize._otherAvatars[message.from] = new BABYLON.Mesh.CreateSphere(message.from, 16, 2, this.parent.visualize._scene);
						var otherAvatarMaterial = new BABYLON.StandardMaterial("otherAvatarMaterial", this.parent.visualize._scene);
						otherAvatarMaterial.diffuseTexture = new BABYLON.Texture("images/beachball_diffuse.jpg", this.parent.visualize._scene);
						this.parent.visualize._otherAvatars[message.from].material = otherAvatarMaterial;
						this.parent.visualize._otherAvatars[message.from].position.x = newMovement.x;
						this.parent.visualize._otherAvatars[message.from].position.y = newMovement.y;
						this.parent.visualize._otherAvatars[message.from].position.z = newMovement.z;
											
						console.log("new player entered the game. Sphere created...");
						//Passing on my information, since the new person will want to know all about us.
						this._reportMyInformation();
					} else if (newMovement.requestAllParticipants === true) {
						//So somebody wants to know who all is in here.
						//Likely this is because they just joined.
						//So we will go ahead and send them a message about ourselves.
						reportMyInformation();
					} else if (newMovement.updateStatus === true) {
						//Hmmm, I might be able to consolidate some of these things different messages, but for
						//now, this is a separate condition. Basically, we can check and 
						//see if this person exists. If they don't exist, we will add them.
						console.log("updateStatus message received. Here are the properties:");
						
						if (typeof this.parent.visualize._otherAvatars[message.from] === "undefined") {
							console.log("An avatar we don't know about announced themselves, and so we added them.");
							this.parent.visualize._otherAvatars[message.from] = BABYLON.Mesh.CreateSphere(message.from, 16, 2, this.parent.visualize._scene);
							var otherAvatarMaterial = new BABYLON.StandardMaterial("otherAvatarMaterial", this.parent.visualize._scene);
							otherAvatarMaterial.diffuseTexture = new BABYLON.Texture("images/beachball_diffuse.jpg", this.parent.visualize._scene);
							this.parent.visualize._otherAvatars[message.from].material = otherAvatarMaterial;
							this.parent.visualize._otherAvatars[message.from].position.x = newMovement.x;
							this.parent.visualize._otherAvatars[message.from].position.y = newMovement.y;
							this.parent.visualize._otherAvatars[message.from].position.z = newMovement.z;						
						}
						else {
							console.log("Avatar updated their status, but we already had them, so we didn't update.");
						}
					} else {
						//So this is not a new player being announced. Instead we will try and
						//move the object that is associated with them.
						//If one doesn't exist, we should try and create one (eventually).
						this.parent.visualize._otherAvatars[message.from].position.x = newMovement.x;
						this.parent.visualize._otherAvatars[message.from].position.y = newMovement.y;
						this.parent.visualize._otherAvatars[message.from].position.z = newMovement.z;
						console.log("Message from other player. I will process it...");
					}
				} else {
					console.log("self movement message. Will ignore it...");
				}
			} else {
				s += " " + this._formatTime(message.sentAt);
				console.log("Inside _processNewMessage: " + message.from);
				console.log("message sent at: " + message.sentAt);
				//s += "<span style=\"color:#" + this._intToARGB(this._hashCode(message.from)) + "\">"
				s += " [";
				if(message.me === true){ s += "<strong>"; }
				s += message.from;
				if(message.me === true){ s += "</strong>"; }
				s += "] ";
				s += "</span>"
				s += message.message;
				s += "</pre>"
				  //var div = document.getElementById(this.parent.defines.chatBoxResponses);
				  //div.innerHTML = s + div.innerHTML;
				  this.parent.defines.chatBoxResponses.innerHTML = s + this.parent.defines.chatBoxResponses.innerHTML;
				  console.log("Chat message should have been posted...");
			}
		}

	console.log("At end of appendMessage()...");
	}


	_sendMessage() {
		var div = document.getElementById("message");
		var message = div.value;
		div.value = "";
		this._client.say(this._client.rooms[this.parent.defines.PLAYER_CHAT_ROOM_NUM], message);
    }
	
	_sendMovementMessage() {
		var messageAsObject = {
			x: this.parent.visualize._myAvatar.position.x,
			y: this.parent.visualize._myAvatar.position.y,
			z: this.parent.visualize._myAvatar.position.z
		};
		var message = JSON.stringify(messageAsObject);
		this._client.say(this._client.rooms[this.parent.defines.MOVEMENT_UPDATES_ROOM_NUM], message);
		console.log("Sent movement message: " + message);
	}

	//NOTE: This breaks internal variable rules (see the underscores),
	//and so it will have to be fixed at some point in time.
	_sendMovementMessageV2(currentCommand) {
		var messageAsObject = {
			x: this.parent.visualize._myAvatar.position.x,
			y: this.parent.visualize._myAvatar.position.y,
			z: this.parent.visualize._myAvatar.position.z
		};
		var message = JSON.stringify(messageAsObject);
		this._client.say(this._client.rooms[this.parent.defines.MOVEMENT_UPDATES_ROOM_NUM], message);
		console.log("Sent movement message: " + message);
	}
	
	//This function announces to the group that
	//this client has just joined, and gives them
	//some basic information about her.
	_announceEntry() {
		console.log("I am requesting all other clients to tell me about themselves. I will also tell them about myself as well.");
		var messageAsObject = {
			newClient: true,
			id: this._client.id,
			body: 'sphere',
			x: this.parent.visualize._myAvatar.position.x,
			y: this.parent.visualize._myAvatar.position.y,
			z: this.parent.visualize._myAvatar.position.z
		};
		var message = JSON.stringify(messageAsObject);
		this._client.say(this._client.rooms[this.parent.defines.MOVEMENT_UPDATES_ROOM_NUM], message);	
	}

	/*
	This method should be called once the connection to the back-end is successfully established.
	For this method will inquire into the correct chat room for a list of all scenery it should download.
	So this list should include it's own avatar (including user name I guess), other avatars, scenery, lights,
	and anything else that should be required. We also need to know where to position all this stuff.
	*/
	_requestSceneData() {
		console.log("I am requesting all other clients to tell me about themselves. I will also tell them about myself as well.");
		var messageAsObject = {
			newClient: true,
			id: this._client.id,
			body: 'sphere',
			x: this.parent.visualize._myAvatar.position.x,
			y: this.parent.visualize._myAvatar.position.y,
			z: this.parent.visualize._myAvatar.position.z
		};
		var message = JSON.stringify(messageAsObject);
		this._client.say(this._client.rooms[this.parent.defines.MOVEMENT_UPDATES_ROOM_NUM], message);	
	}
	
	//This function reports this avatars information to the
	//group. So this isn't when we are new to the group,
	//but rather somebody else wants to update their list. 
	//Likely this is because THEY are new and need to get
	//a good picture of the room.
	_reportMyInformation() {
		console.log("I am reporting my current information, because somebody asked for it.");
		var messageAsObject = {
			updateStatus: true,
			id: this._client.id,
			body: 'sphere',
			x: this.parent.visualize._myAvatar.position.x,
			y: this.parent.visualize._myAvatar.position.y,
			z: this.parent.visualize._myAvatar.position.z
		};
		var message = JSON.stringify(messageAsObject);
		this._client.say(this._client.rooms[this.parent.defines.MOVEMENT_UPDATES_ROOM_NUM], message);	
	}
	
	
	
	//Call this function to send out a group wide request for all
	//current participants. So basically when you first join the room,
	//you need to ask who all is here, and then you can build up
	//the appropriate visual image from the responses.
	_requestAllCurrentParticipants() {
		var messageAsObject = {
			requestAllParticipants: true
		}
		var message = JSON.stringify(messageAsObject);
		this._client.say(this._client.rooms[this.parent.defines.MOVEMENT_UPDATES_ROOM_NUM], message);
	}
	
	_formatTime(timestamp) {
		console.log("formatting timestamp: " + timestamp);
      return new Date(timestamp).toLocaleTimeString()
    }

	_hashCode(str) { // java String#hashCode
        var hash = 0;
        for (var i = 0; i < str.length; i++) {
           hash = str.charCodeAt(i) + ((hash << 5) - hash);
        }
        return hash;
    }

	_intToARGB(i) {
        var color =
          ((i>>24)&0xFF).toString(16) +
          ((i>>16)&0xFF).toString(16) +
          ((i>> 8)&0xFF).toString(16) +
          (i&0xFF).toString(16);
        return color.substring(0, 6);
    }
	
}

/*
This is intended to be a private sub-class of VSpace.
It is a handy place to store definitions and other static,
common resources.
*/
class VSpace_Defines {
	constructor(messageBoxName, chatBoxName, parent){
		this.parent = parent;
		console.log("Inside Defines constructor...");
		this.chatMessageBox = document.getElementById(messageBoxName);
		this.chatBoxResponses = document.getElementById(chatBoxName);
		
		this.PLAYER_CHAT_ROOM_NUM = 0;
		this.MOVEMENT_UPDATES_ROOM_NUM = 1;
		
		//This is where you specify which keys do what things.
		//Currently, these are the WASD keys, with control to kick, and space to jump
		this.COMMANDS = {
			NONE: 0,
			UP: 87,
			LEFT: 65,
			RIGHT: 68,
			DOWN: 83,
			JUMP: 32, 
			KICK: 17
		},

		//Eventually we decipher the commands the user gives and combines them
		//into a coherent action. So we can choose one of the following:
		this.DIRECTIONS = {
			NONE: 0,
			NORTH: 1,
			NORTHEAST: 2,
			EAST: 3,
			SOUTHEAST: 4,
			SOUTH: 5,
			SOUTHWEST: 6,
			WEST: 7,
			NORTHWEST: 8,
			JUMP: 9,
			KICK: 10
		}		
	}
}


/*
This is intended to be a private sub-class of VSpace.
It is responsible for listening for the user commands,
and interpreting them for the rest of the code.
So it should emit events to the rest of the code.
For example, "move north" should be emitted to all interested
parties when the "up" arrow is pushed.
*/
class VSpace_Commands {
	constructor(parent){
		console.log("Inside Commands constructor...");
		this.parent = parent;
		this.currentCommand = this.parent.defines.DIRECTIONS.NORTHEAST;
		
		//NOTE: by supplying the "this" object as the callback, and by creating a
		//custom method called "handleEvent", we are actually
		//calling this.handleEvent(), complete with the correct variable scope. 
		//Strange, I know, but it works...
		window.addEventListener('keydown', this, true);
		window.addEventListener('keyup', this, true);
		//When they are typing a chat message, we don't want Babylon to move our character around the screen.
		//So we trap for this event, and then temporarily turn off listening for key presses.
		this.parent.defines.chatMessageBox.addEventListener("focus", this, false);
		
		//After the chat message has been sent, and they no longer have focus on
		//the message input box, we want to turn on listening for keys.
		this.parent.defines.chatMessageBox.addEventListener("blur", this, false);
		
		
		//Important key states:
		//So keyboard buttons get pushed, and we keep track of the important ones
		//separately. This means we know if many buttons are pushed, and can execute
		//moves that require several buttons pushed.
		//true means it is currently pushed down.
		//false means it is currently not pushed down (released).
		this._keyStates = {
			up: false,
			left: false,
			right: false,
			down: false,
			jump: false,
			kick: false
		}		
	}

	/*So the currentCommand is processed by the Visualize object.
	However we have set up event listeners in other objects (especially Communication)
	that must know about changes. So we report changes in the public value,
	and then also update the private, backer variable.
	*/
	get currentCommand(){
		return this._currentCommand;
	}
	set currentCommand(newCommand){
		this._currentCommand = newCommand;
		this.parent.events.fireOffEvent("currentCommand", newCommand);
	}
	
	/*
	So apparently if you register to listen for events, and if the object you pass in has
	a method called "handleEvent", you can trap for your own events. I wouldn't go to all of this
	trouble, because Babylon has an event manager, but I was having issues with scope. In order
	to pass in the right function with the correct scope, I needed to bind() it. However if you
	bind() events, there is trouble with deregistering the events when you are done: it simply won't
	deregister them. This is when I stumbled upon this handleEvents() idea.
	https://www.thecssninja.com/javascript/handleevent
	So we will handle everything ourselves, and life is good again.
	*/
	handleEvent(event){
		if (event.type === "keydown"){
			//console.log("Event raised: " + event.type);
			this._onKeyDown(event);
		} else if (event.type === "keyup"){
			//console.log("Event raised: " + event.type);
			this._onKeyUp(event);
		} else if (event.type === 'focus' && event.target === this.parent.defines.chatMessageBox) {
			window.removeEventListener('keydown', this, true);
			window.removeEventListener('keyup', this, true);
			//console.log("Removing keydown and keyup event listeners...");
		} else if (event.type === 'blur' && event.target === this.parent.defines.chatMessageBox){
			window.addEventListener('keydown', this, true);
			window.addEventListener('keyup', this, true);
			//console.log("Add keydown and keyup event listeners...");
		}
	}
		
	/*
	This is one function, activated by various listeners,
	that decides what, if anything, the user is trying to tell us.
	It is basically looking for keyboard keys actively being pushed down.
	*/
	_onKeyDown(event) {
		//alert("DOWN");
		var DEF = this.parent.defines;
		switch(event.keyCode){
			case DEF.COMMANDS.UP://this.definitions.COMMANDS.UP:
				this._keyStates.up = true;
				if (this._keyStates.left === true){
					this.currentCommand = DEF.DIRECTIONS.NORTHWEST;
				} else if (this._keyStates.right === true){
					this.currentCommand = DEF.DIRECTIONS.NORTHEAST;
				} else {
					this.currentCommand = DEF.DIRECTIONS.NORTH;
				}
				break;
			case DEF.COMMANDS.LEFT:
				this._keyStates.left = true;
				if (this._keyStates.up === true){
					this.currentCommand = DEF.DIRECTIONS.NORTHWEST;
				} else if (this._keyStates.down === true){
					this.currentCommand = DEF.DIRECTIONS.SOUTHWEST;
				} else {
					this.currentCommand = DEF.DIRECTIONS.WEST;
				}
				break;
			case DEF.COMMANDS.RIGHT:
				this._keyStates.right = true;
				if (this._keyStates.up === true){
					this.currentCommand = DEF.DIRECTIONS.NORTHEAST;
				} else if (this._keyStates.down === true){
					this.currentCommand = DEF.DIRECTIONS.SOUTHEAST;
				} else {
					this.currentCommand = DEF.DIRECTIONS.EAST;
				}
				break;
			case DEF.COMMANDS.DOWN:
				this._keyStates.down = true;
				if (this._keyStates.left === true){
					this.currentCommand = DEF.DIRECTIONS.SOUTHWEST;
				} else if (this._keyStates.right === true){
					this.currentCommand = DEF.DIRECTIONS.SOUTHEAST;
				} else {
					this.currentCommand = DEF.DIRECTIONS.SOUTH;
				}
				break;
			case DEF.COMMANDS.JUMP:
				this._keyStates.jump = true;
				this.currentCommand = DEF.DIRECTIONS.JUMP;
				break;
			case DEF.COMMANDS.KICK:
				this._keyStates.kick = true;
				this.currentCommand = DEF.DIRECTIONS.KICK;
				break;
		}
		console.log('currentCommand (key down): ' + this.currentCommand);
	}


	/*
	This is one function, activated by various listeners,
	that decides what, if anything, the user is trying to tell us.
	It is basically looking for keyboard keys actively being released.
	*/
	_onKeyUp(event) {
		//alert("UP");	
		var DEF = this.parent.defines;	
		switch(event.keyCode){
			case DEF.COMMANDS.UP:
				this._keyStates.up = false;
				if (this._keyStates.left === true){
					this.currentCommand = DEF.DIRECTIONS.WEST;
				} else if (this._keyStates.right === true){
					this.currentCommand = DEF.DIRECTIONS.EAST;
				} else {
					this.currentCommand = DEF.DIRECTIONS.NONE;
				}
				break;
			case DEF.COMMANDS.LEFT:
				this._keyStates.left = false;
				if (this._keyStates.up === true){
					this.currentCommand = DEF.DIRECTIONS.NORTH;
				} else if (this._keyStates.down === true){
					this.currentCommand = DEF.DIRECTIONS.SOUTH;
				} else {
					this.currentCommand = DEF.DIRECTIONS.NONE;
				}
				break;
			case DEF.COMMANDS.RIGHT:
				this._keyStates.right = false;
				if (this._keyStates.up === true){
					this.currentCommand = DEF.DIRECTIONS.NORTH;
				} else if (this._keyStates.down === true){
					this.currentCommand = DEF.DIRECTIONS.SOUTH;
				} else {
					this.currentCommand = DEF.DIRECTIONS.NONE;
				}
				break;
			case DEF.COMMANDS.DOWN:
				this._keyStates.down = false;
				if (this._keyStates.left === true){
					this.currentCommand = DEF.DIRECTIONS.WEST;
				} else if (this._keyStates.right === true){
					this.currentCommand = DEF.DIRECTIONS.EAST;
				} else {
					this.currentCommand = DEF.DIRECTIONS.NONE;
				}
				break;
			case DEF.COMMANDS.JUMP:
				this._keyStates.jump = false;
				this.currentCommand = DEF.DIRECTIONS.NONE;
				break;
			case DEF.COMMANDS.KICK:
				this._keyStates.kick = false;
				this.currentCommand = DEF.DIRECTIONS.NONE;
				break;
		}
		console.log('currentCommand (key up): ' + this.currentCommand);
	}	
}

/*
So the plan is that the various objects (mainly Visualize and Connection)
will register events, and subscribe to events from each other. This will be 
the official way to pass messages back and forth. So it will be callbacks
when events are raised.
*/
class VSpace_Events{
	constructor(){
		this.eventSubscribers = [];
	}
	
	/*
	So call this when you have an event that occurred.
	NOTE: you don't care if anybody has subscribed to
	the event. You are just calling it and your job is done.
	It is the job of this method to check if anybody actually
	cares about the event and alert them.
	parameters:
	name: <string> event name
	parameters: <object> any information that may be needed by the 
		subscriber that the event thinks it should possess. This might
		be null, and the actual data the object possesses can be
		whatever the two parties agree upon.
	*/
	fireOffEvent(name, parameters){
		//console.log ("Event fired off!");
		for (let subscriber of this.eventSubscribers) {
			//console.log("Event subscriber: " + subscriber.name);
			if (subscriber.name === name){
				//console.log("Event subscriber found! Now would be the time to fire off the function...");
				subscriber.action(parameters);
			}
		}
	}
	
	/*
	So this is where you register for an event.
	NOTE: There may or may not be an event that 
	is ever called, but it shouldn't matter.
	parameters:
	name: <string> - the name of an event
	action: <function> - the name of a function
		to call when this event occurs
	*/
	subscribeToEvent(name, action){
		var eventSubscriber = new EventSubscriber(name, action);
		this.eventSubscribers.push(eventSubscriber);
	}
	
	/*
	If you want to stop listening to an event, call this
	method, and it will remove the callback from the list
	NOTE: This is untested!
	*/
	unsubscribeToEvent(name, action){
		var eventSubscriberToDelete = new EventSubscriber(name, action);
		this.eventSubscribers = this.eventSubscribers.filter(function(currentSubscriber) {return !(eventSubscriberToDelete === currentSubscriber)});
	}
}

/*
In the class VSpace_Events, we can subscribe to and fire off
certain events. Each event subscriber is an object of this class.
So this class needs to hold the name of the event we are interested in,
as well as what callback method to to fire off
*/
class EventSubscriber{
	constructor(name, action){
		this.name = name;
		this.action = action;
	}
}